//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:expense_tracker/models/data_item.dart';
//import 'package:expense_tracker/widgets/list_item.dart';
//import 'package:flutter/material.dart';
//import 'package:rflutter_alert/rflutter_alert.dart';
//
//final firestore = Firestore.instance.collection('data');
//
//class TransactionList extends StatefulWidget {
//  @override
//  _TransactionListState createState() => _TransactionListState();
//}
//
//class _TransactionListState extends State<TransactionList> {
//
//
//  @override
//  Widget build(BuildContext context) {
//    return ;
//  }
//}
