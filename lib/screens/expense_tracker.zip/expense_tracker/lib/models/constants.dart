
const List<String> flatMates = [
  'Ananthu',
  'Rohit',
  'Jishnu',
  'J K',
  'Deepu',
  'Vishnu',
  'Godwin',
  'Tony',
  'Alwin'
];
//
//void getAndSetUsers(BuildContext ctx) async{
//  FutureBuilder(builder: (ctx,snapshot){
//    print(snapshot.data);
//    return ;
//  },future: Firestore.instance.collection('users').getDocuments(),);
//}