class DataItem {
  DataItem({this.dId,this.dTitle, this.dPayee, this.dAmount, this.dDate, this.dTotal});
  final String dPayee;
  final String dId;
  final String dAmount;
  final String dTitle;
  final String dDate;
  final double dTotal;
}
